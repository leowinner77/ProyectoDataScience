library( readxl)
library(psych)
library(tidyverse)
library(ggrepel)
library(dslabs)
library(visreg)
library(tmap)
library(tmaptools)
library(rgdal)
library(sf)
library(maps)
library(tigris)
options(tigris_use_cache = TRUE)



#Leemos los archivos descargados en excel y creamos las variables para la cantidad de periodos y las variables a trabajar

Periodo <- c(2021:1990)
Gen_energetico <- read_excel("us.xlsx", sheet = "5. Generation", skip = 3, na = ".")
Emisiones_CO2 <- read_excel("us.xlsx", sheet = "7. Emissions", skip = 2)
Consumo_petroleo <- read_excel("Table_2.5_Transportation_Sector_Energy_Consumption.xlsx", sheet = "Annual Data", skip = 10)
PIB_per_capita <- read_excel("GDPpercapita.xls")
Intensidad_estado <- read_excel("table5.xlsx", skip = 4)
Emisiones_estado <- read_excel("table1.xlsx", skip = 4)
Total <- "Total electric industry"
Particulas <- "Carbon dioxide"
Pais <- "USA"
Estados <- state.name
download.file("http://www2.census.gov/geo/tiger/GENZ2015/shp/cb_2015_us_state_20m.zip", destfile = "states.zip")
unzip("states.zip")
us_geo<- st_read("cb_2015_us_state_20m.shp")



#Se limpian las bases de datos, nos quedamos con lo necesario en el periodo establecido.

colnames(Gen_energetico)[1] <- "Energy"
Gen_energetico_limpio <-  Gen_energetico %>% 
  filter(Energy %in% Total) %>%
  pivot_longer(cols = 2:33, names_to="year", values_to ="Energy_output") %>%
  select("year", "Energy_output") %>%
  mutate(across('year', str_replace, 'Year', '')) %>%
  transform(year = as.numeric(year))


Emisiones_CO2_limpio <- Emisiones_CO2 %>%
  rename(Emission_type = "Emission type") %>%
  filter(Emission_type %in% Particulas) %>%
  pivot_longer(cols = 2:33, names_to="year", values_to ="Carbon_dioxide") %>%
  select("year", "Carbon_dioxide") %>%
  mutate(across('year', str_replace, 'Year', '')) %>%
  transform(year = as.numeric(year))
  

Consumo_petroleo_limpio <- Consumo_petroleo %>%
  rename(year = "Annual Total") %>%
  rename(Petroleum_Consumption = "Petroleum Consumed by the Transportation Sector (Excluding Biofuels)") %>%
  filter(year %in% Periodo) %>%
  select(year, 
  Petroleum_Consumption) %>%
  transform(Petroleum_Consumption = as.numeric(Petroleum_Consumption))

PIB_per_capita_limpio <- PIB_per_capita %>%
  na.omit() %>%
  pivot_longer(cols = 2:49, names_to = "year",
               values_to = "USGDP_per_capita") %>%
  select(year, USGDP_per_capita) %>%
  filter(year %in% Periodo)%>%
  transform(year = as.numeric(year))

#Una vez limpiada toda la data, se procede a crear una lista con cada una de las variables, y unirlas en un df por los años en común

list_model = list(Emisiones_CO2_limpio, PIB_per_capita_limpio, Gen_energetico_limpio, Consumo_petroleo_limpio)
data <- list_model %>%
  reduce(inner_join, by = "year")

#Se realizan los graficos por cada variable

ggplot(data, aes(x = year, y= Energy_output)) + 
  geom_line(color="yellow", size = 2)+
  scale_color_brewer(palette="Paired")+
  theme_minimal()+
  labs(title="Evolución de la generación de energía",x="Año", y = "Generación (mWh)")


ggplot(data, aes(x = year, y= Petroleum_Consumption)) + 
  geom_line(color="red", size = 2)+
  scale_color_brewer(palette="Paired")+
  theme_minimal()+
  labs(title="Evolución del consumo del petróleo del sector transporte",x="Año", y = "Consumo de Petróleo (billones de BTU)")

ggplot(data, aes(x = year, y= USGDP_per_capita)) + 
  geom_line(color="green", size = 2)+
  scale_color_brewer(palette="Paired")+
  theme_minimal()+
  labs(title="Evolución del PIB per cápita",x="Año", y = "PIB per cápita")

ggplot(data, aes(x = year, y= Carbon_dioxide)) + 
  geom_line(color="black", size = 2)+
  scale_color_brewer(palette="Paired")+
  theme_minimal()+
  labs(title="Evolución de las emisiones de carbono",x="Año", y = "Emisiones de CO2 (lbs/MWh)")


#Ahora con el nuevo df, se procede a realizar el modelo de regresión lineal.

model <- lm(Carbon_dioxide ~ Energy_output + Petroleum_Consumption + USGDP_per_capita, data = data )
summary(model)  

#Realizamos los graficos de regresion de LOESS entre las variables explicativas y la variable a explicar


ggplot(data, aes(x = Energy_output, y= Carbon_dioxide)) + 
  geom_point() + 
  geom_smooth()+
  scale_color_brewer(palette="Paired")+
  theme_minimal()+
  labs(title="Relación entre las Emisiones de CO2 y la Generación de energía",x="Generación de energía (mWh)", y = "Emisiones de CO2 (lbs/MWh)")

ggplot(data, aes(x = Petroleum_Consumption, y= Carbon_dioxide)) + 
  geom_point() + 
  geom_smooth()+
  scale_color_brewer(palette="Paired")+
  theme_minimal()+
  labs(title="Relación entre las Emisiones de CO2 y el consumo de petróleo del sector transporte",x="Consumo de Petróleo del sector transporte (billones BTU)", y = "Emisiones de CO2 (lbs/MWh)")


ggplot(data, aes(x = USGDP_per_capita, y= Carbon_dioxide)) + 
  geom_point() + 
  geom_smooth()+
  scale_color_brewer(palette="Paired")+
  theme_minimal()+
  labs(title="Relación entre las Emisiones de CO2 y el PIB per cápita",x="PIB per cápita", y = "Emisiones de CO2 (lbs/MWh)")


#Realizamos los graficos de regresiones lineales entre cada una de las variables explicativas y la variable a explicar

visreg(model, xvar="Energy_output", yvar="Carbon_dioxide", 
       line.colour="red", xlab="Generación de energía (mWh)", ylab="Emisiones de CO2")

visreg(model, xvar="Petroleum_Consumption", yvar="Carbon_dioxide", 
      line.colour="red", xlab="Consumo de Petróleo del sector transporte (billones BTU)", ylab="Emisiones de CO2")

visreg(model, xvar="USGDP_per_capita", yvar="Carbon_dioxide", 
      line.colour="red", xlab="PIB per cápita", ylab="Emisiones de CO2")


#Mapa de intensidad energética de USA por Estado

Intensidad_estado_limpio <- Intensidad_estado %>%
  select(State, "2020") %>%
  filter(State %in% Estados)

mapa_intensidad <- merge(us_geo, Intensidad_estado_limpio, by.x = "NAME", by.y = "State") %>%
rename(Year_2020 = "2020")

mapa <- qtm(mapa_intensidad, fill = "Year_2020", fill.title = "Intensidad energética (2020)") 
mapa_interactivo <- tmap_leaflet(mapa) 
mapa_interactivo

#Mapa de contaminacion de CO2 (energy-related) de USA por Estado


Emisiones_estado_limpio <- Emisiones_estado %>%
  select(State, "2020") %>%
  filter(State %in% Estados)

CO2mapa <- merge(us_geo, Emisiones_estado_limpio, by.x = "NAME", by.y = "State") %>%
  rename(Year_2020 = "2020")

mapa2 <- qtm(CO2mapa, fill = "Year_2020", fill.title = "Emisiones CO2 del sector energía (2020)", fill.n = 9) 
mapa_interactivo2 <- tmap_leaflet(mapa2) 
mapa_interactivo2

